
package javafx.bdats_sema_tluchor.obyvatele;

/**
 *
 * @author atluc
 */
public enum enumPozice {
    PRVNI,
    POSLEDNI,
    PREDCHUDCE,
    NASLEDNIK,
    AKTUALNI
}
