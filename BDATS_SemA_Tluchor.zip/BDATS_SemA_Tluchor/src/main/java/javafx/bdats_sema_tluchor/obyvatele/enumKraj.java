package javafx.bdats_sema_tluchor.obyvatele;

/**
 *
 * @author atluc
 */
public enum enumKraj {
    HLAVNI_MESTO_PRAHA,    // 1
    JIHOCESKY,             // 2
    JIHOMORAVSKY,          // 3
    KARLOVARSKY,           // 4
    KRAJ_VYSOCINA,         // 5
    KRALOVEHRADECKY,       // 6
    LIBERECKY,             // 7
    MORAVSKOSLEZSKY,       // 8
    OLOMOUCKY,             // 9
    PARDUBICKY,            // 10
    PLZENSKY,              // 11
    STREDOCESKY,           // 12
    USTECKY,               // 13
    ZLINSKY;               // 14

    
    
}
