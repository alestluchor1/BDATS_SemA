
package javafx.bdats_sema_tluchor.obyvatele;

/**
 *
 * @author atluc
 */
public class ObyvateleException extends Exception {
    
    public ObyvateleException(String msg) {
        super(msg);
    }
}
