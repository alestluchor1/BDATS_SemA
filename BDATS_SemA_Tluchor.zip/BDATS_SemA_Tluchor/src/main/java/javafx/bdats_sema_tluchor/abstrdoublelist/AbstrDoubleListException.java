package javafx.bdats_sema_tluchor.abstrdoublelist;


/**
 *
 * @author atluc
 */
public class AbstrDoubleListException extends Exception {

    public AbstrDoubleListException(String msg) {
        super(msg);
    }
    
}
