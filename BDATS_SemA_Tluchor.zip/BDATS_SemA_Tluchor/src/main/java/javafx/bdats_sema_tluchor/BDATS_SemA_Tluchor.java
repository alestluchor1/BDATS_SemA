

package javafx.bdats_sema_tluchor;

import javafx.bdats_sema_tluchor.GUI.ProgObyvatele;

/**
 *
 * @author atluc
 */
public class BDATS_SemA_Tluchor {
    public static void main(String[] args) {
        ProgObyvatele.main(args); // Spuštění GUI třídy
    }
}

